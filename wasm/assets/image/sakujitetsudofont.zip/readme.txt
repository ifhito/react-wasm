作字鉄道書体 / Sakujitetsudo Font


ライセンス / License
CC BY 4.0（https://creativecommons.org/licenses/by/4.0/）


収録文字 / Collected characters
作字鉄道書体本非常停止釦代用手信号現示位置特殊発光機急行安全定輸送交運転士車掌回乗率臨時勾配起動踏切立受最大力東海列線アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンヴガギグゲゴザジズゼゾダヂヅデドバビブベボパピプペポァィゥェォッャュョー？


著作権表示 / Copyright notice
© 2019 Sakujitetsu